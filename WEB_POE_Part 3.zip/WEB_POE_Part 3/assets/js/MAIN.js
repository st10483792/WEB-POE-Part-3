// Main JS for Part 3 features
document.addEventListener('DOMContentLoaded', function(){
  // Modal
  const modal = document.getElementById('modal');
  const open = document.getElementById('open-modal');
  const close = document.getElementById('close-modal');
  const specialText = document.getElementById('special-text');
  if(open){
    open.addEventListener('click', ()=> {
      specialText.textContent = "Buy any 2 pastries, get 1 free today!";
      modal.setAttribute('aria-hidden','false');
    });
  }
  if(close){ close.addEventListener('click', ()=> modal.setAttribute('aria-hidden','true'))}

  // Gallery lightbox
  document.querySelectorAll('.thumb').forEach(img=>{
    img.addEventListener('click', (e)=>{
      const src = img.dataset.full || img.src;
      const light = document.createElement('div');
      light.style.position='fixed';light.style.inset='0';light.style.display='flex';
      light.style.alignItems='center';light.style.justifyContent='center';
      light.style.background='rgba(0,0,0,.8)';
      const im = document.createElement('img');
      im.src = src; im.style.maxWidth='90%'; im.style.maxHeight='90%';
      light.appendChild(im);
      light.addEventListener('click', ()=> document.body.removeChild(light));
      document.body.appendChild(light);
    });
  });

  // Accordion
  document.querySelectorAll('.accordion-toggle').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const panel = btn.nextElementSibling;
      panel.classList.toggle('show');
    });
  });

  // Dynamic product list (example data)
  const products = [
    {id:1,name:'Sourdough Loaf',price:45,category:'bread'},
    {id:2,name:'Chocolate Cake',price:350,category:'cake'},
    {id:3,name:'Cinnamon Roll',price:25,category:'pastry'}
  ];
  // render products on Products page
  const productsDiv = document.getElementById('products');
  if(productsDiv){
    products.forEach(p=>{
      const el = document.createElement('div'); el.className='product';
      el.innerHTML = `<strong>${p.name}</strong><div>R${p.price}</div><div>${p.category}</div>`;
      productsDiv.appendChild(el);
    });
  }

  // Search on index page
  const productList = document.getElementById('product-list');
  const search = document.getElementById('search');
  if(search && productList){
    function renderList(filtered){
      productList.innerHTML = '';
      filtered.forEach(p=>{
        const d = document.createElement('div'); d.className='product';
        d.innerHTML = `<strong>${p.name}</strong> — R${p.price}`;
        productList.appendChild(d);
      });
    }
    renderList(products);
    search.addEventListener('input', ()=> {
      const q = search.value.toLowerCase().trim();
      const filtered = products.filter(p=> p.name.toLowerCase().includes(q) || p.category.includes(q));
      renderList(filtered);
    });
  }

  // Contact form validation + AJAX-like submit (simulated)
  const contactForm = document.getElementById('contact-form');
  if(contactForm){
    contactForm.addEventListener('submit', function(e){
      e.preventDefault();
      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const phone = document.getElementById('phone').value.trim();
      const message = document.getElementById('message').value.trim();
      const result = document.getElementById('contact-result');
      if(name.length<2){ result.textContent='Please enter your name.'; return;}
      if(!email.includes('@')){ result.textContent='Enter a valid email.'; return;}
      if(phone.length<7){ result.textContent='Enter a valid phone number.'; return;}
      // simulate AJAX
      setTimeout(()=> {
        result.textContent = 'Message compiled. Opening email client...';
        // open mailto (populated)
        const subject = encodeURIComponent('Contact from '+name+' ('+document.getElementById('msgtype').value+')');
        const body = encodeURIComponent('Phone: '+phone+'\\n\\n'+message);
        window.location.href = `mailto:info@sweettreats.example?subject=${subject}&body=${body}`;
      },600);
    });
  }

  // Enquiry form behavior
  const etype = document.getElementById('etype');
  const serviceFields = document.getElementById('service-fields');
  if(etype){
    etype.addEventListener('change', ()=> {
      serviceFields.style.display = etype.value==='service' ? 'block' : 'none';
    });
  }
  const enquiryForm = document.getElementById('enquiry-form');
  if(enquiryForm){
    enquiryForm.addEventListener('submit', function(e){
      e.preventDefault();
      const ename = document.getElementById('ename').value.trim();
      const etypev = document.getElementById('etype').value;
      const qty = document.getElementById('qty')?.value || 1;
      const product = document.getElementById('product')?.value || '';
      const result = document.getElementById('enquiry-result');
      if(ename.length<2){ result.textContent='Enter your full name.'; return;}
      if(!etypev){ result.textContent='Select enquiry type.'; return;}
      if(etypev==='service'){
        // simple availability check
        const available = qty<=20;
        result.textContent = available ? `Available. Estimated cost: R${qty * 25}` : 'Not available in requested quantity.';
      } else {
        result.textContent = 'Thanks — we will contact you about '+etypev;
      }
    });
  }

  // Simple accessibility: keyboard close modal with Escape
  document.addEventListener('keydown', (e)=> {
    if(e.key==='Escape') modal && modal.setAttribute('aria-hidden','true');
  });

});
